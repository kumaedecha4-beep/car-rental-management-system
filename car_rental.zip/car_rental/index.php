<?php include 'includes/header.php';

// list available cars
$result = $conn->query("SELECT * FROM cars WHERE status='available'");
?>

<h2>Available Cars</h2>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px">
<?php while($car = $result->fetch_assoc()): ?>
  <div class="card">
    <?php if($car['image']): ?>
      <img src="<?php echo e($car['image']); ?>" alt="car" style="width:100%;height:150px;object-fit:cover;border-radius:6px;margin-bottom:8px">
    <?php endif; ?>
    <h3><?php echo e($car['make'].' '.$car['model']); ?> (<?php echo e($car['year']); ?>)</h3>
    <p>Seats: <?php echo e($car['seats']); ?> &middot; USD <?php echo e(number_format($car['price_per_day'],2)); ?> / day</p>
    <div class="flex">
      <a class="btn btn-primary" href="user/book_car.php?car_id=<?php echo e($car['id']); ?>">Book</a>
      <a class="btn" href="/car_rental/contact.php">Contact</a>
    </div>
  </div>
<?php endwhile; ?>
</div>

<?php include 'includes/footer.php'; ?>







