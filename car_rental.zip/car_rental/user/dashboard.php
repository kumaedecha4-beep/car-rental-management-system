<?php include '../includes/header.php'; if(!is_logged_in()){ header('Location: ../login.php'); exit; }
$user = current_user();
?>
<h2>Welcome, <?php echo e($user['username']); ?></h2>
<p>
  <a href="book_car.php" class="btn btn-primary">Book a Car</a>
  <a href="my_bookings.php" class="btn">My Bookings</a>
  <a href="profile.php" class="btn">Profile</a>
</p>
<?php include '../includes/footer.php'; ?>