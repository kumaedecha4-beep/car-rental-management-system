<?php include '../includes/header.php'; if(!is_logged_in()){ header('Location: ../login.php'); exit; }
$car_id = (int)($_GET['car_id'] ?? 0);
$res = $conn->query("SELECT * FROM cars WHERE id={$car_id} LIMIT 1");
if(!$res || !$res->num_rows){ echo 'Car not found'; include '../includes/footer.php'; exit; }
$car = $res->fetch_assoc();
$errors = [];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $start = $_POST['start_date'];
  $end = $_POST['end_date'];
  if(!$start || !$end) $errors[]='Select dates.';
  $d1 = new DateTime($start);
  $d2 = new DateTime($end);
  if($d2 < $d1) $errors[]='End must be after start.';
  $days = $d2->diff($d1)->days + 1;
  $total = $days * $car['price_per_day'];
  if(empty($errors)){
    $uid = current_user()['id'];
    $stmt = $conn->prepare("INSERT INTO bookings (user_id,car_id,start_date,end_date,total_price) VALUES (?,?,?,?,?)");
    $stmt->bind_param('iissd',$uid,$car_id,$start,$end,$total);
    if($stmt->execute()){
      echo '<div class="card">Booking placed. <a href="my_bookings.php">My bookings</a></div>';
      include '../includes/footer.php'; exit;
    } else $errors[]='DB error';
  }
}
?>
<h2>Book: <?php echo e($car['make'].' '.$car['model']); ?></h2>
<p>Price per day: USD <?php echo e(number_format($car['price_per_day'],2)); ?></p>
<?php foreach($errors as $er) echo "<div style='color:red'>".e($er)."</div>"; ?>
<form method="post">
  <label>Start Date</label>
  <input type="date" name="start_date" required>
  <label>End Date</label>
  <input type="date" name="end_date" required>
  <button class="btn btn-primary">Confirm Booking</button>
</form>
<?php include '../includes/footer.php'; ?>