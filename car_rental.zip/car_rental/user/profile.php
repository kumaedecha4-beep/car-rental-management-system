<?php 
include '../includes/header.php'; 

if (!is_logged_in()) { 
    header('Location: ../login.php'); 
    exit; 
}

$user = current_user();
$errors = [];

// -------- REMOVE IMAGE ----------
if(isset($_POST['remove_photo'])){
    $conn->query("UPDATE users SET photo=NULL WHERE id={$user['id']}");
    $_SESSION['user']['photo'] = null;
    echo "<div style='color:green'>Photo Removed</div>";
}

// -------- FORM PROCESS ----------
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cropped_image'])){

    // EMAIL UPDATE
    $email = $conn->real_escape_string($_POST['email']);
    if(!$email) $errors[] = 'Email required.';

    if(empty($errors)){

        // ----- SAVE CROPPED IMAGE ------
        if(!empty($_POST['cropped_image'])){
            $img = $_POST['cropped_image'];  
            $img = str_replace('data:image/png;base64,', '', $img);
            $img = base64_decode($img);

            $filename = "user_".$user['id']."_".time().".png";
            file_put_contents("../uploads/".$filename, $img);

            $conn->query("UPDATE users SET photo='{$filename}' WHERE id={$user['id']}");
            $_SESSION['user']['photo'] = $filename;
        }

        // EMAIL SAVE
        $conn->query("UPDATE users SET email='{$email}' WHERE id={$user['id']}");
        $_SESSION['user']['email'] = $email;

        echo '<div style="color:green; margin:10px 0;">Profile Updated</div>';
    }
}
?>

<h2>Profile</h2>

<?php
$photo = !empty($user['photo']) ? "../uploads/".$user['photo'] : "../assets/default.png"; 
?>
<img id="profile_pic" 
     src="<?php echo $photo; ?>" 
     style="width:120px; height:120px; border-radius:50%; object-fit:cover; margin-bottom:15px;">

<form method="post" enctype="multipart/form-data">

  <label>Email</label>
  <input name="email" value="<?php echo e($user['email']); ?>">

  <label>Change Profile Photo</label>
  <input type="file" id="image_input" accept="image/*">

  <!-- Hidden field for cropped image -->
  <input type="hidden" name="cropped_image" id="cropped_image">

  <button class="btn btn-primary">Save</button>
</form>

<form method="post">
    <button name="remove_photo" style="margin-top:10px; background:red; color:white; padding:8px; border:none; border-radius:4px;">
        Remove Photo
    </button>
</form>


<!-- CROP MODAL -->
<div id="crop_modal" 
     style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; 
            background:rgba(0,0,0,0.8); justify-content:center; align-items:center;">
    
    <div style="background:#fff; padding:20px; border-radius:8px;">
        <img id="crop_image" style="max-width:400px;">
        <button id="crop_btn" style="margin-top:10px;">Crop</button>
        <button onclick="closeModal()">Cancel</button>
    </div>
</div>

<script>
let cropper;

// Open modal when image selected
document.getElementById('image_input').addEventListener('change', function(e){
    let file = e.target.files[0];

    if (!file) return;

    // Size limit 2MB
    if(file.size > 2*1024*1024){
        alert("Max size 2MB");
        e.target.value = "";
        return;
    }

    let reader = new FileReader();
    reader.onload = function(event){
        document.getElementById('crop_image').src = event.target.result;
        openModal();

        // Initialize cropper
        setTimeout(() => {
            cropper = new Cropper(document.getElementById('crop_image'), {
                aspectRatio: 1,
                viewMode: 1
            });
        }, 200);
    };
    reader.readAsDataURL(file);
});

function openModal(){
    document.getElementById('crop_modal').style.display = "flex";
}

function closeModal(){
    document.getElementById('crop_modal').style.display = "none";
    if (cropper) cropper.destroy();
}

document.getElementById('crop_btn').addEventListener('click', function(){
    let canvas = cropper.getCroppedCanvas({
        width: 300,
        height: 300
    });

    let croppedImage = canvas.toDataURL("image/png");
    document.getElementById('cropped_image').value = croppedImage;

    // Show preview
    document.getElementById('profile_pic').src = croppedImage;

    closeModal();
});
</script>

<?php include '../includes/footer.php'; ?>
