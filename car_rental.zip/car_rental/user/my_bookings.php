<?php 
include '../includes/header.php'; 

if(!is_logged_in()){ 
    header('Location: ../login.php'); 
    exit; 
}

$uid = current_user()['id'];
$res = $conn->query("SELECT b.*, c.make, c.model FROM bookings b JOIN cars c ON b.car_id=c.id WHERE b.user_id={$uid} ORDER BY b.created_at DESC");
?>

<h2>My Bookings</h2>
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Car</th>
      <th>From</th>
      <th>To</th>
      <th>Total</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo e($r['id']); ?></td>
        <td><?php echo e($r['make'].' '.$r['model']); ?></td>
        <td><?php echo e($r['start_date']); ?></td>
        <td><?php echo e($r['end_date']); ?></td>
        <td><?php echo e(number_format($r['total_price'],2)); ?></td>
        <td><?php echo e($r['status']); ?></td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<?php include '../includes/footer.php'; ?>
