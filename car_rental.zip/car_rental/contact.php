<?php include 'includes/header.php';

$errors = [];
$sent = false;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if(!$name || !$email || !$message) $errors[] = 'All fields are required.';

    if(empty($errors)){
        // Save message in database
        $stmt = $conn->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $message);
        $stmt->execute();

        $sent = true;
    }
}
?>
<h2>Contact</h2>
<?php if($sent): ?>
  <div class="card">Thank you. Your message was received.</div>
<?php else: ?>
  <?php if($errors): foreach($errors as $e): ?>
    <div style="color:red"><?php echo e($e); ?></div>
  <?php endforeach; endif; ?>
  <form method="post">
    <label>Name</label>
    <input name="name">
    <label>Email</label>
    <input name="email">
    <label>Message</label>
    <textarea name="message" style="width:100%;height:120px"></textarea>
    <button class="btn btn-primary" type="submit">Send</button>
  </form>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
