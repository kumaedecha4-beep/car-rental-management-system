    <?php
    $servername = "localhost"; // Yeroo baay'ee "localhost" dha
    $username = "root";        // Username MySQL kee (yeroo baay'ee "root" dha)
    $password = "1234"; // <-- PASSWORD KEE SIRRII GALCHI
    $dbname = "car_rental";    // Database kee maqaa isaa (yoo "car_rental" ta'e)

    // Connection uumuuf
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Connection ilaaluuf
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // echo "Connected successfully"; // Yoo barbaadde connection hojjechuu isaa mirkaneessuuf
    ?>
