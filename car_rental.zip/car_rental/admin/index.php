<?php
include '../includes/header.php';
if(!is_admin()){ header('Location: ../login.php'); exit; }

// counts
$users = $conn->query('SELECT COUNT(*) as c FROM users')->fetch_assoc()['c'];
$cars = $conn->query('SELECT COUNT(*) as c FROM cars')->fetch_assoc()['c'];
$bookings = $conn->query('SELECT COUNT(*) as c FROM bookings')->fetch_assoc()['c'];

// messages file path
$messages_file = '../messages.txt';
$messages = [];
if(file_exists($messages_file)){
    $messages = file($messages_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f7;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }

        .flex {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px auto;
            flex-wrap: wrap;
        }

        .card {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
            width: 200px;
            font-size: 18px;
            color: #333;
        }

        .btn {
            display: inline-block;
            padding: 10px 18px;
            margin-right: 10px;
            background: #2e86de;
            color: white;
            border-radius: 6px;
            text-decoration: none;
        }

        .btn:hover {
            background: #1e6fcc;
        }

        /* Messages box */
        .messages-container {
            width: 90%;
            max-width: 900px;
            margin: 30px auto;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-height: 300px;
            overflow-y: auto;
        }

        .message {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            margin-bottom: 10px;
            background: #f9f9f9;
            border-radius: 6px;
        }

        .message:last-child {
            border-bottom: none;
        }

        .message strong {
            color: #2e86de;
        }
    </style>
</head>
<body>

<h2>Admin Dashboard</h2>

<div class="flex">
    <div class="card">Users: <?php echo e($users); ?></div>
    <div class="card">Cars: <?php echo e($cars); ?></div>
    <div class="card">Bookings: <?php echo e($bookings); ?></div>
</div>

<p style="text-align:center; margin-top:12px;">
    <a href="manage_cars.php" class="btn">Manage Cars</a>
    <a href="manage_booking.php" class="btn">Manage Bookings</a>
    <a href="manage_users.php" class="btn">Manage Users</a>
</p>

<h2>Contact Messages</h2>
<div class="messages-container">
<?php
if($messages){
    foreach($messages as $msg){
        echo "<div class='message'><pre>".htmlspecialchars($msg)."</pre></div>";
    }
} else {
    echo "<p>No messages yet.</p>";
}
?>
</div>

</body>
</html>
