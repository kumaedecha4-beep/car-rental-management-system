<?php
include '../includes/header.php';
if(!is_admin()){ header('Location: ../login.php'); exit; }

// counts
$users = $conn->query('SELECT COUNT(*) as c FROM users')->fetch_assoc()['c'];
$cars = $conn->query('SELECT COUNT(*) as c FROM cars')->fetch_assoc()['c'];
$bookings = $conn->query('SELECT COUNT(*) as c FROM bookings')->fetch_assoc()['c'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-top: 40px;
            font-size: 30px;
        }

        /* FLEX CONTAINER FOR CARDS */
        .flex {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 30px;
        }

        /* DASHBOARD CARDS */
        .card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 30px 40px;
            font-size: 20px;
            font-weight: bold;
            color: #34495e;
            text-align: center;
            flex: 1 1 200px;
            min-width: 200px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        /* BUTTONS */
        .btn {
            display: inline-block;
            background: #3498db;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            margin-right: 10px;
            transition: background 0.3s;
        }

        .btn:hover {
            background: #2980b9;
        }

        p {
            text-align: center;
            margin-top: 40px;
        }

        /* RESPONSIVE */
        @media(max-width: 600px){
            .flex {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 80%;
                padding: 20px;
            }

            .btn {
                display: block;
                margin: 10px auto;
            }
        }
    </style>
</head>
<body>

<h2>Admin Dashboard</h2>

<div class="flex">
    <div class="card">Users: <?php echo e($users); ?></div>
    <div class="card">Cars: <?php echo e($cars); ?></div>
    <div class="card">Bookings: <?php echo e($bookings); ?></div>
</div>

<p>
    <a href="manage_cars.php" class="btn">Manage Cars</a>
    <a href="manage_booking.php" class="btn">Manage Bookings</a>
    <a href="manage_users.php" class="btn">Manage Users</a>
</p>

<?php include '../includes/footer.php'; ?>
</body>
</html>
