<?php
session_start(); // ✨ Added for logout system
include 'db.php'; // db.php is inside admin folder

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $make  = trim($_POST['make']);
    $model = trim($_POST['model']);
    $year  = trim($_POST['year']);
    $seats = trim($_POST['seats']);
    $price = trim($_POST['price_per_day']);

    if (empty($make))  $errors[] = "Car make is required.";
    if (empty($model)) $errors[] = "Car model is required.";
    if (empty($year))  $errors[] = "Car year is required.";
    if (empty($seats)) $errors[] = "Number of seats is required.";
    if (empty($price)) $errors[] = "Price per day is required.";

    if (!isset($_FILES['car_image']) || $_FILES['car_image']['error'] !== 0) {
        $errors[] = "Car image is required.";
    }

    if (empty($errors)) {
        $file_name = time() . "_" . basename($_FILES['car_image']['name']);
        $target_path = "../uploads/" . $file_name;

        move_uploaded_file($_FILES['car_image']['tmp_name'], $target_path);

        $image_path = "uploads/" . $file_name;

        $stmt = $conn->prepare("
            INSERT INTO cars (make, model, year, seats, price_per_day, image, status)
            VALUES (?, ?, ?, ?, ?, ?, 'available')
        ");

        $stmt->bind_param("sssids", $make, $model, $year, $seats, $price, $image_path);
        $stmt->execute();

        echo "<p style='color: green; text-align:center;'>Car added successfully!</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Car</title>
    <style>
        /* GLOBAL STYLES */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        a { text-decoration: none; }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-top: 30px;
            font-size: 28px;
        }

        /* LOGOUT BUTTON */
        .logout-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #e74c3c;
            padding: 10px 18px;
            border-radius: 6px;
            color: white;
            font-weight: bold;
            transition: 0.3s;
        }
        .logout-btn:hover {
            background: #c0392b;
        }

        /* FORM CONTAINER */
        .container {
            width: 500px;
            max-width: 90%;
            margin: 40px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .container input[type="text"],
        .container input[type="number"],
        .container input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
        }

        .container button {
            width: 100%;
            padding: 14px;
            background: #3498db;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
        }

        .container button:hover {
            background: #2980b9;
        }

        .error {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 15px;
            font-weight: bold;
        }

        /* AVAILABLE CARS */
        .cars-container {
            width: 95%;
            max-width: 1000px;
            margin: 40px auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 25px;
        }

        .car-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: transform 0.2s;
        }
        .car-card:hover {
            transform: translateY(-5px);
        }

        .car-card img {
            width: 100%;
            max-height: 180px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .car-details {
            font-size: 15px;
            color: #2c3e50;
            line-height: 1.5;
        }

        .car-details strong {
            font-size: 17px;
            color: #34495e;
        }

    </style>
</head>
<body>

<a href="logout.php" class="logout-btn">Logout</a>

<h2>Add New Car</h2>

<div class="container">
    <?php
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p class='error'>$error</p>";
        }
    }
    ?>

    <form action="add_car.php" method="POST" enctype="multipart/form-data">
        Car Make:
        <input type="text" name="make">

        Car Model:
        <input type="text" name="model">

        Year:
        <input type="number" name="year">

        Seats:
        <input type="number" name="seats">

        Price Per Day:
        <input type="number" step="0.01" name="price_per_day">

        Car Image:
        <input type="file" name="car_image">

        <button type="submit">Add Car</button>
    </form>
</div>

<h2>Available Cars</h2>

<div class="cars-container">
<?php
$result = $conn->query("SELECT * FROM cars ORDER BY id DESC");

while ($row = $result->fetch_assoc()) {
    echo "<div class='car-card'>";

    if (!empty($row['image'])) {
        echo "<img src='../" . $row['image'] . "'>";
    } else {
        echo "<img src='no-image.png'>";
    }

    echo "<div class='car-details'>";
    echo "<strong>" . $row['make'] . " " . $row['model'] . "</strong><br>";
    echo "Year: " . $row['year'] . "<br>";
    echo "Seats: " . $row['seats'] . "<br>";
    echo "Price: $" . $row['price_per_day'] . " per day<br>";
    echo "Status: " . $row['status'] . "<br>";
    echo "</div>";

    echo "</div>";
}
?>
</div>

</body>
</html>
