<?php include '../includes/header.php'; if(!is_admin()){ header('Location: ../login.php'); exit; }
$id = (int)($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM cars WHERE id={$id} LIMIT 1");
if(!$res || !$res->num_rows){ echo 'Not found'; include '../includes/footer.php'; exit; }
$car = $res->fetch_assoc();
$errors = [];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $make = $conn->real_escape_string($_POST['make']);
  $model = $conn->real_escape_string($_POST['model']);
  $year = (int)$_POST['year'];
  $seats = (int)$_POST['seats'];
  $price = (float)$_POST['price_per_day'];
  $status = $conn->real_escape_string($_POST['status']);
  $image = $conn->real_escape_string($_POST['image']);
  $sql = "UPDATE cars SET make='{$make}',model='{$model}',year={$year},seats={$seats},price_per_day={$price},status='{$status}',image='{$image}' WHERE id={$id}";
  if($conn->query($sql)){
    header('Location: manage_cars.php'); exit;
  } else $errors[]='Update failed.';
}
?>
<h2>Edit Car #<?php echo e($car['id']); ?></h2>
<?php foreach($errors as $er) echo "$er<br>"; ?>
<form method="post">
  <label>Make</label><input name="make" value="<?php echo e($car['make']); ?>">
  <label>Model</label><input name="model" value="<?php echo e($car['model']); ?>">
  <label>Year</label><input name="year" type="number" value="<?php echo e($car['year']); ?>">
  <label>Seats</label><input name="seats" type="number" value="<?php echo e($car['seats']); ?>">
  <label>Price per day</label><input name="price_per_day" type="number" step="0.01" value="<?php echo e($car['price_per_day']); ?>">
  <label>Status</label>
  <select name="status">
    <option value="available" <?php if($car['status']==='available') echo 'selected'; ?>>available</option>
    <option value="unavailable" <?php if($car['status']==='unavailable') echo 'selected'; ?>>unavailable</option>
  </select>
  <label>Image path</label><input name="image" value="<?php echo e($car['image']); ?>">
  <button class="btn btn-primary">Update</button>
</form>
<?php include '../includes/footer.php'; ?>