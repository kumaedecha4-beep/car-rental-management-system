<?php
include '../includes/header.php';
if(!is_admin()){ header('Location: ../login.php'); exit; }

$id = intval($_GET['id'] ?? 0);

if($id){
    $conn->query("UPDATE messages SET status='read' WHERE id={$id}");
}

header('Location: messages.php');
exit;
?>
