<?php
include '../includes/header.php';
if(!is_admin()){ header('Location: ../login.php'); exit; }

$result = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");
?>

<h2>Contact Messages</h2>

<table>
    <thead>
     <tr>
    <td><?php echo e($row['id']); ?></td>
    <td><?php echo e($row['name']); ?></td>
    <td><?php echo e($row['email']); ?></td>
    <td><?php echo e($row['message']); ?></td>
    <td><?php echo e($row['created_at']); ?></td>
    <td>
        <?php if($row['status'] == 'unread'): ?>
            <a href="mark_read.php?id=<?php echo e($row['id']); ?>" class="btn">Mark as Read</a>
        <?php else: ?>
            Read
        <?php endif; ?>
    </td>
</tr>
   








    <?php endwhile; ?>
    </tbody>
</table>

<?php include '../includes/footer.php'; ?>
