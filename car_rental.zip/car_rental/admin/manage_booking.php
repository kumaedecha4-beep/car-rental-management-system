<?php include '../includes/header.php'; if(!is_admin()){ header('Location: ../login.php'); exit; }
$res = $conn->query('SELECT b.*, u.username, c.make, c.model FROM bookings b JOIN users u ON b.user_id=u.id JOIN cars c ON b.car_id=c.id ORDER BY b.created_at DESC');
?>
<h2>Bookings</h2>
<table>
  <thead><tr><th>#</th><th>User</th><th>Car</th><th>From</th><th>To</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php while($r=$res->fetch_assoc()): ?>
    <tr>
      <td><?php echo e($r['id']); ?></td>
      <td><?php echo e($r['username']); ?></td>
      <td><?php echo e($r['make'].' '.$r['model']); ?></td>
      <td><?php echo e($r['start_date']); ?></td>
      <td><?php echo e($r['end_date']); ?></td>
      <td><?php echo e(number_format($r['total_price'],2)); ?></td>
      <td><?php echo e($r['status']); ?></td>
      <td>
        <a href="change_booking_status.php?id=<?php echo e($r['id']); ?>&status=confirmed">Confirm</a> |
        <a href="change_booking_status.php?id=<?php echo e($r['id']); ?>&status=cancelled">Cancel</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
<?php include '../includes/footer.php'; ?>