<?php include '../includes/header.php'; if(!is_admin()){ header('Location: ../login.php'); exit; }
$res = $conn->query('SELECT id,username,email,role,created_at FROM users ORDER BY id DESC');
?>
<h2>Users</h2>
<table>
  <thead><tr><th>#</th><th>Username</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
  <tbody>
  <?php while($u=$res->fetch_assoc()): ?>
    <tr>
      <td><?php echo e($u['id']); ?></td>
      <td><?php echo e($u['username']); ?></td>
      <td><?php echo e($u['email']); ?></td>
      <td><?php echo e($u['role']); ?></td>
      <td><?php echo e($u['created_at']); ?></td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
<?php include '../includes/footer.php'; ?>