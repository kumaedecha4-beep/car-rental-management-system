<?php include '../includes/header.php'; if(!is_admin()){ header('Location: ../login.php'); exit; }
$res = $conn->query('SELECT * FROM cars ORDER BY created_at DESC');
?>
<h2>Manage Cars</h2>
<p><a href="add_car.php" class="btn btn-primary">Add Car</a></p>
<table>
  <thead><tr><th>#</th><th>Car</th><th>Year</th><th>Seats</th><th>Price/day</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php while($c = $res->fetch_assoc()): ?>
    <tr>
      <td><?php echo e($c['id']); ?></td>
      <td><?php echo e($c['make'] . ' ' . $c['model']); ?></td>
      <td><?php echo e($c['year']); ?></td>
      <td><?php echo e($c['seats']); ?></td>
      <td><?php echo e(number_format($c['price_per_day'],2)); ?></td>
      <td><?php echo e($c['status']); ?></td>
      <td>
        <a href="edit_car.php?id=<?php echo e($c['id']); ?>">Edit</a> |
        <a href="delete_car.php?id=<?php echo e($c['id']); ?>" onclick="return confirm('Delete?')">Delete</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
<?php include '../includes/footer.php'; ?>