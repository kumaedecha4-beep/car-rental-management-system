<?php include '../includes/header.php'; if(!is_admin()){ header('Location: ../login.php'); exit; }
$id = (int)($_GET['id'] ?? 0);
if($id){ $conn->query("DELETE FROM cars WHERE id={$id}"); }
header('Location: manage_cars.php'); exit;