<?php include '../includes/header.php'; if(!is_admin()){ header('Location: ../login.php'); exit; }
$id = (int)($_GET['id'] ?? 0);
$status = $conn->real_escape_string($_GET['status'] ?? 'pending');
if($id && in_array($status,['pending','confirmed','cancelled'])){
  $conn->query("UPDATE bookings SET status='{$status}' WHERE id={$id}");
}
header('Location: manage_booking.php'); exit;