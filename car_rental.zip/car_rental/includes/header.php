<?php include_once __DIR__.'/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Car Rental</title>

<style>
body{font-family:Arial,sans-serif;margin:0;padding:0;background:#f6f7fb;color:#222}
.container{max-width:1000px;margin:20px auto;padding:20px;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,0.06)}
header{display:flex;align-items:center;justify-content:space-between}
nav a{margin-right:12px;text-decoration:none;color:#2b6cb0}
.btn{display:inline-block;padding:8px 12px;border-radius:6px;text-decoration:none}
.btn-primary{background:#2b6cb0;color:#fff}
.btn-danger{background:#e53e3e;color:#fff}
table{width:100%;border-collapse:collapse}
th,td{padding:8px;border-bottom:1px solid #eee;text-align:left}
.card{border:1px solid #eee;padding:12px;border-radius:8px}
form input, form select, form textarea{padding:8px;width:100%;box-sizing:border-box;margin-bottom:8px}
.flex{display:flex;gap:12px}
.right{margin-left:auto}
footer{margin-top:20px;text-align:center;color:#666}
</style>

<!-- ⭐ Add Cropper.js CSS and JS here (Correct Location) -->
<link rel="stylesheet" 
      href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css">
<script 
      src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js">
</script>
<!-- ⭐ End Cropper.js -->

</head>
<body>
<div class="container">
<header>
  <div>
    <h1>Car Rental</h1>
    <p style="margin:0">Simple car rental management system</p>
  </div>
  <nav>
    <a href="/car_rental/index.php">Home</a>
    <a href="/car_rental/about.php">About</a>
    <a href="/car_rental/contact.php">Contact</a>

    <?php if(is_logged_in()): ?>
        <?php if(is_admin()): ?>
          <a href="/car_rental/admin/dashboard.php">Admin</a>
        <?php else: ?>
          <a href="/car_rental/user/dashboard.php">My Account</a>
        <?php endif; ?>
        <a href="/car_rental/logout.php">Logout (<?php echo e(current_user()['username']); ?>)</a>
    <?php else: ?>
        <a href="/car_rental/login.php">Login</a>
        <a href="/car_rental/register.php" class="btn btn-primary">Register</a>
    <?php endif; ?>

  </nav>
</header>
<hr>
