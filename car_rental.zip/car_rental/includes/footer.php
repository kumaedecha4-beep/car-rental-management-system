<hr>
<footer>
<p>&copy; <?php echo date('Y'); ?> Car Rental. All rights reserved.</p>
</footer>
</div>
</body>
</html>
