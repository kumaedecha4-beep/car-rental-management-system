<?php
session_start();

// Database credentials for XAMPP
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '1234';  // your XAMPP MySQL password
$db_name = 'car_rental';

// Connect
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die('Connection failed: '.$conn->connect_error);
}

// Helpers
function e($str){ return htmlspecialchars($str, ENT_QUOTES, 'UTF-8'); }
function is_logged_in(){ return isset($_SESSION['user']); }
function current_user(){ return $_SESSION['user'] ?? null; }
function is_admin(){ return is_logged_in() && ($_SESSION['user']['role'] === 'admin'); }
?>
