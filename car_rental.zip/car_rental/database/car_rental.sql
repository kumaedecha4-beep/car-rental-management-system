DROP DATABASE IF EXISTS car_rental;
CREATE DATABASE car_rental CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE car_rental;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE cars (
  id INT AUTO_INCREMENT PRIMARY KEY,
  make VARCHAR(100) NOT NULL,
  model VARCHAR(100) NOT NULL,
  year YEAR NOT NULL,
  seats INT NOT NULL,
  price_per_day DECIMAL(10,2) NOT NULL,
  image VARCHAR(255) DEFAULT NULL,
  status ENUM('available','unavailable') DEFAULT 'available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  car_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO users (username,email,password,role) VALUES
('admin','admin@example.com','123456','admin'),
('user1','user1@example.com','user123','user');

INSERT INTO cars (make, model, year, seats, price_per_day, image, status) VALUES
('Toyota','Corolla',2018,5,1000,'images/car_pictures_here/corolla.jpg','available'),
('Honda','Civic',2019,5,1200,'images/car_pictures_here/civic.jpg','available'),
('Suzuki','Swift',2018,4,30.00,'images/car_pictures_here/swift.jpg','available');
