<?php 
include 'includes/header.php';
$errors = [];

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $res = $conn->query("SELECT * FROM users WHERE username='{$username}' LIMIT 1");

    if($res && $res->num_rows){
        $user = $res->fetch_assoc();
        if($password === $user['password']){ // plain text check
            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role']
            ];

            if($user['role'] === 'admin'){
                header('Location: admin/dashboard.php');
            } else {
                header('Location: user/dashboard.php');
            }
            exit;
        }
    }

    $errors[] = 'Invalid credentials.';
}
?>

<h2>Login</h2>

<?php foreach($errors as $err): ?>
<div style="color:red;"><?php echo e($err); ?></div>
<?php endforeach; ?>

<form method="post">

    <label>Username</label>
    <input name="username" required>

    <label>Password</label>
    <input name="password" type="password" required>

    <!-- RED LOGIN BUTTON -->
    <button style="
        background:blue; 
        color:white; 
        padding:10px 20px; 
        border:none; 
        border-radius:5px; 
        font-size:16px;
        cursor:pointer;
        margin-top:10px;
    ">
        Login
    </button>

</form>

<?php include 'includes/footer.php'; ?>
