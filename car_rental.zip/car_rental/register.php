<?php include 'includes/header.php';
$errors = [];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if(!$username || !$email || !$password) $errors[]='All fields required.';
    if($password !== $confirm) $errors[]='Passwords do not match.';

    if(empty($errors)){
        $sql = "INSERT INTO users (username,email,password) VALUES ('{$username}','{$email}','{$password}')";
        if($conn->query($sql)){
            echo '<div class="card">Registration successful. <a href="login.php">Login</a></div>';
            include 'includes/footer.php';
            exit;
        } else { $errors[]='Username or email already exists.'; }
    }
}
?>

<h2>Register</h2>
<?php foreach($errors as $err) echo "<div style='color:red'>".e($err)."</div>"; ?>
<form method="post">
<label>Username</label><input name="username" required>
<label>Email</label><input name="email" type="email" required>
<label>Password</label><input name="password" type="password" required>
<label>Confirm Password</label><input name="confirm_password" type="password" required>
<button class="btn btn-primary">Register</button>
</form>

<?php include 'includes/footer.php'; ?>
