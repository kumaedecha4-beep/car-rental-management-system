<?php include 'includes/header.php'; ?>
<h2>About Us</h2>
<p>We provide affordable rental cars for short and long trips. This is a demo project.</p>
<?php include 'includes/footer.php'; ?>